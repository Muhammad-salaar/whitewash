
var AllTodos = [];

var Type_AllTodos = JSON.stringify(AllTodos)

localStorage.setItem("AllTodos",Type_AllTodos)


function AddTodoFunc(){
    


    var taskInput = document.getElementById("userTodo").value
    var dateInput = document.getElementById("userDate").value


    var newUser =  {
        task:taskInput,
        date:dateInput,
        status:"incomp"
    }


    AllTodos.push(newUser)

  
    var Type_AllTodos = JSON.stringify(AllTodos)

    localStorage.setItem("AllTodos",Type_AllTodos)

    ReadTask();
}





function ReadTask(){
    var tbody = document.getElementById("tbodyData");
    tbody.innerHTML = " ";
    // localstorage se sare task manga rahe hen 

    var items = localStorage.getItem("AllTodos");


    // todoItems ek array he jisme mene localstorage se data retrv kraker save kia he array format me
    var todoItems = JSON.parse(items)



    todoItems.forEach(  
        (element,index)=>{
            
         


            tbody.innerHTML += `
            
             <tr id=${index}>

                    <th>${index+1}</th>
                    <td>${element.task}</td>
                    <td>${element.date}</td>
                    <th scope="col">
                            <button class="btn btn-secondary btn-sm" onclick="CompleteTask('${element.task}')">Complete</button>
                        <button class="btn btn-danger btn-sm">Delete</button>
                    </th>

                </tr>
           
            `
        

        }
    )

}


function CompleteTask(task){



    var items = localStorage.getItem("AllTodos");
    
    var todoItems = JSON.parse(items);




    // var singleTask = todoItems.find(options=>options.task == task);


    // singleTask.status = "complete"





    


    // singleTask.status = "comp"


    // console.log(singleTask)
   

    // var SingleTodo = todoItems.find()

    // console.log()




}


